library(raster)
library(rtravelcost)

memory.limit(999999999999)
memory.size(999999999999)


startTime = Sys.time()
result <- accumcosts(x="./examples/inputs/frictiongrid.tif", y="./examples/inputs/targetcities.shp",
           directions=8, outputpath1="./examples/outputs/result1.tif",
           outputpath2="./examples/outputs/result2.tif", nblocks=5, format="GTiff", field="fid", rollX=FALSE, rollY=FALSE)

print(Sys.time() - startTime)

plot(result$result1)
