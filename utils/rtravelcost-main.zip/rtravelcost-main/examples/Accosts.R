library(raster)
library(rtravelcost)

x <- raster(nrows=6, ncols=7, xmn=0, xmx=7, ymn=0, ymx=6, crs="+proj=utm +units=m")
x[] <- c(2, 2, 1, 1, 5, 5, 5,
         2, 2, 8, 8, 5, 2, 1,
         7, 1, 1, 8, 2, 2, 2,
         8, 7, 8, 8, 8, 8, 5,
         8, 8, 1, 1, 5, 3, 9,
         8, 1, 1, 2, 5, 3, 9)


y <- raster(nrows=6, ncols=7, xmn=0, xmx=7, ymn=0, ymx=6, crs="+proj=utm +units=m")
y[] <- c(NA, NA, NA, NA, NA, NA, NA,
         NA, NA, NA, NA, NA, NA, NA,
         NA, NA, NA, NA, NA, NA, NA,
         NA, NA, NA, NA, NA, NA, NA,
         NA, NA, NA, NA, NA, 10, NA,
         NA, NA, NA, NA, NA, NA, NA)


result = accosts(x, y, 4, 1, FALSE, FALSE)

plot(result$layer.1)
text(result$layer.1)

