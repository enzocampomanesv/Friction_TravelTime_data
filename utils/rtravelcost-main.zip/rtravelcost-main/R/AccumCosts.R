if (!isGeneric('accumcosts')) {
  setGeneric("accumcosts", function(x, y, directions, ...)
  standardGeneric("accumcosts") )
}

setMethod("accumcosts",
          signature(x = "character", y= "character"),
          def = function(x, y, directions=8,
                         nblocks=1, rollX=FALSE, rollY=FALSE, outputpath1="access_min.tif",
                         outputpath2="access_zones.tiff", field="", format="GTiff")
          {
            return (.Taccosts(x, y, directions, nblocks, rollX, rollY, outputpath1, outputpath2, field, format))
})

.Taccosts <- function(x, y, directions, nblocks, rollX, rollY, outputpath1, outputpath2, field, format){
  if(!file.exists(x)){
    stop(paste('Path for the input friction file is invalid: ', x, sep=" "))
  }
  if(!file.exists(y)){
    stop(paste('Path for the input target file is invalid: ', y, sep=" "))
  }
  do_Accosts(x, y, directions, nblocks,outputpath1, outputpath2, field, format, rollX, rollY)
  if (file.exists(outputpath1) && file.exists(outputpath2))
    return (raster::stack(raster::raster(outputpath1), raster::raster(outputpath2)))
}
