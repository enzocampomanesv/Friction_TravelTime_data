setGeneric("accosts", function(x, y, directions, ...)
  standardGeneric("accosts") )

setMethod("accosts",
          signature(x = "RasterLayer", y= "RasterLayer"),
          def = function(x, y, directions,
                         nblocks=1, rollX=FALSE, rollY=FALSE)
{
  return (.Taccost(x, y, directions, nblocks, rollX, rollY))

})

.Taccost <- function(x, y, directions, nblocks, rollX, rollY)
{
  ncols <- ncol(x)
  nrows <- nrow(x)
  xmin <- xmin(x)
  ymax <- ymax(x)

  nodataval <- -9999.0

  # Call the c++ accost function
  # The result is a matrix of travel cost and catchments values

  result <- doAccost(getValues(x), getValues(y), nrows, ncols, nblocks, directions, xres(x), -yres(x), xmin(x), ymax(x), nodataval, isLonLat(x), rollX, rollY)

  # Create a rasterstack
  startTime = Sys.time()
  c1 <- as(x, 'RasterLayer')
  c1 <- setValues(c1, result[1,])

  c2 <- as(x, 'RasterLayer')
  c2 <- setValues(c2, result[2,])

  return(raster::stack(c1, c2))
}
