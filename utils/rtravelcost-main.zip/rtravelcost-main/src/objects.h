#pragma once
#define _USE_MATH_DEFINES
#define _CRT_SECURE_NO_WARNINGS
#include <RcppCommon.h>
#include <cmath>
#include<iostream>
#include<vector>

using namespace std;

struct Move {
  int x, y;
  Move(int x, int y) : x(x), y(y) {}
  Move():x(0), y(0){}
  ~Move(){}
};

struct Point {
  int id;
  int x, y;
  Point(int id, int x, int y) : id(id), x(x), y(y) {}
  Point():id(0), x(0), y(0) {}
  ~Point() {}
};

struct States {
  std::vector<float> costs;
  std::vector<int> sources;
  std::vector<bool> visited;
  std::vector<Move> moves;
  std::vector<std::vector<float>> dist;
  States(std::vector<float> costs, std::vector<int> sources,
         std::vector<bool> visited, std::vector<Move> moves, std::vector<std::vector<float>> dist)
    : costs(costs), sources(sources), visited(visited), moves(moves), dist(dist) {}
  States() : costs(std::vector<float>(0)),
  sources(std::vector<int>(0)), visited(std::vector<bool>(0)),
  moves(std::vector<Move>(0)), dist(std::vector<std::vector<float>>(0, std::vector<float>(0))) {}
  ~States() {}
};

struct Options {
  int nrows, ncols, directions, xblocksize, yblocksize;
  float xres, yres, xmin, ymax, nodataval;
  bool isLatLon, rollX, rollY;
  Options(int nrows, int ncols, int xblocksize, int yblocksize, int directions, float xres, float yres, float xmin, float ymax, float nodataval, bool isLatLon, bool rollX, bool rollY)
    : nrows(nrows), ncols(ncols), xblocksize(xblocksize), yblocksize(yblocksize), directions(directions), xres(xres), yres(yres), xmin(xmin), ymax(ymax), nodataval(nodataval), isLatLon(isLatLon), rollX(rollX), rollY(rollY) {}

};

struct options {
  int directions, xblocksize, yblocksize;
  bool rollX, rollY;
  string filename1, filename2, field, format;
  options(int directions, int xblocksize, int yblocksize, bool rollX, bool rollY, string filename1, string filename2, string field, string format):
    directions(directions), xblocksize(xblocksize), yblocksize(yblocksize), rollX(rollX), rollY(rollY), filename1(filename1),
    filename2(filename2), field(field), format(format){}
};
