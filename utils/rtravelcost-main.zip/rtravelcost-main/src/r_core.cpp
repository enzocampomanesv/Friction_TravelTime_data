#include "core.h"

using namespace Rcpp;
using namespace std;


// [[Rcpp::export]]
NumericMatrix doPixFromCell(unsigned ncols, NumericVector cell) {
  size_t len = cell.size();
  NumericMatrix result(len, 2);
  for (size_t i = 0; i < len; i++) {
    int c = cell[i] - 1;
    int row = floor(c / ncols);
    int col = c - row * ncols;
    result(i,0) = row;
    result(i,1) = col;
  }
  return result;
}

std::vector<Point> doGetPoints(unsigned ncols, NumericVector vals) {
  size_t len = vals.size();
  vector<Point> points;
  int count = 0;
  for (size_t i = 0; i < len; i++) {
    if(!NumericVector::is_na(vals[i])){
      int row = floor(i / ncols);
      int col = i - row * ncols;
      points.push_back(Point(vals[i], col, row));
      count++;
    }
  }
  points.resize(count);
  return points;
}


std::vector<float> replaceNA(NumericVector vals, float toVal) {
  size_t len = vals.size();
  std::vector<float> result(len);
  for (size_t i = 0; i < len; i++) {
    if(NumericVector::is_na(vals[i])){
      result[i] = toVal;
    }else{
      result[i] = vals[i];
    }
  }
  return result;
}

IntegerVector getNoDataCells(NumericVector vals, float nodataVal) {
  size_t len = vals.size();
  IntegerVector result;
  for (size_t i = 0; i < len; i++) {
    if(NumericVector::is_na(vals[i])){
      result.push_back(i);
    }
  }
  return result;
}


// [[Rcpp::export]]
NumericMatrix doAccost(NumericVector  x, NumericVector y, int nrows, int ncols,
                                int nblocks, int directions, float xres, float yres, float xmin, float ymax, float nodataval,
                                bool isLatLon, bool wrapX, bool wrapY) {
  /*int nr = y.nrow();
  vector<Point> points(nr);
  for( size_t i=0; i<nr; i++) {
    points[i] = Point(int(y(i, 0)), int(y(i, 1)), int(y(i, 2)));
  }*/

  vector<Point> points = doGetPoints(ncols, y);

  std::vector<float> data =  replaceNA(x, nodataval);

  Options opts(nrows, ncols, nblocks, nblocks, directions, xres, yres, xmin, ymax, nodataval, isLatLon, wrapX, wrapY);
  int size = x.size();
  NumericMatrix res(2, size);

  States states = accost(ref(data), ref(points), ref(opts));

  for (int i = 0; i < size; i++) {
    float cost = states.costs[i];
    if (cost == -1) {
      res(0, i) = NA_REAL;
      res(1, i) = NA_REAL;
    }else{
      res(0, i) = cost;
      res(1, i) = states.sources[i];
    }
  }
  return res;
}

// [[Rcpp::export]]
void do_Accosts(std::string srcFilename, std::string sourceLayer, int directions, int nblocks,
                std::string outputpath1, std::string outputpath2, std::string field, std::string format, bool rollX, bool rollY){

  options opts(directions, nblocks, nblocks, rollX, rollY, outputpath1, outputpath2, field, format);

  CPLPushErrorHandler(CPLQuietErrorHandler);
  GDALAllRegister();

  GDALDataset *frictionDs, *layerDs, *rasterizeDs;

  frictionDs = (GDALDataset*)GDALOpen(srcFilename.c_str(), GA_ReadOnly);
  if (frictionDs == NULL)
  {
    Rcpp::Rcout << "Invalid format or path for the dataset  " <<  srcFilename.c_str() << std::endl;
    Rcpp::stop("Creation failed.\n");
  }

  layerDs = (GDALDataset*)GDALOpen(sourceLayer.c_str(), GA_ReadOnly);
  if (layerDs == NULL)
  {
    layerDs = (GDALDataset*)GDALOpenEx(sourceLayer.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL);
    if (layerDs == NULL)
    {
      Rcpp::Rcout << "Invalid format or path for the dataset  " <<  sourceLayer.c_str() << std::endl;
      Rcpp::stop("Creation failed.\n");
    }

    GDALDriver* poDriver;
    poDriver = GetGDALDriverManager()->GetDriverByName("Mem");
    if (poDriver == NULL) {
      fprintf(stderr, "Error allocating memory");
      exit(EXIT_FAILURE);
    }

    rasterizeDs = poDriver->Create("",
                                   frictionDs->GetRasterXSize(), frictionDs->GetRasterYSize(), 1, GDT_Float32, NULL);
    double adfGeoTransform[6];
    if (frictionDs->GetGeoTransform(adfGeoTransform) == CE_None) {
    }
    rasterizeDs->SetGeoTransform(adfGeoTransform);
    rasterizeDs->SetProjection(frictionDs->GetProjectionRef());
    rasterizeDs->GetRasterBand(1)->SetNoDataValue(-9999.0);
    rasterizeDs->GetRasterBand(1)->Fill(-9999.0);
    int bands[1] = { 1 };

    OGRLayerH pahLayers[1];
    pahLayers[0] = (OGRLayerH*)layerDs->GetLayer(0);
    double* burn_values_list = (double*)CPLMalloc(sizeof(double) * 1);
    for (int i = 0; i < 1; i++)
      burn_values_list[i] = -9999.0;

    char** options = nullptr;
    options = CSLSetNameValue(options, "ATTRIBUTE",field.c_str());

    GDALRasterizeLayers(rasterizeDs, 1, bands, layerDs->GetLayerCount(), pahLayers, NULL, NULL, burn_values_list, options, NULL, NULL);
    writeRaster(frictionDs, rasterizeDs, opts);
    CPLFree(burn_values_list);
    if (rasterizeDs != NULL) GDALClose((GDALDatasetH)rasterizeDs);
  }else{
    writeRaster(frictionDs, layerDs, opts);
    if (layerDs != NULL) GDALClose((GDALDatasetH)layerDs);
    if (frictionDs != NULL)  GDALClose((GDALDatasetH)frictionDs);
  }
  GDALDestroyDriverManager();
}
