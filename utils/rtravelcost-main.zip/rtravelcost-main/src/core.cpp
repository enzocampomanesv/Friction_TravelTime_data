#include <Rcpp.h>
using namespace Rcpp;
using namespace std;
#include "core.h"
#include <tuple>
#include <queue>
#include<map>
#include <thread>
#include<functional>
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>


// Define the radius of the semi-major and semi minor axes
#define semi_major 6378137
#define semi_minor 6356752.314245

// Calculate the flattening f
#define f (semi_major - semi_minor)/semi_major

// Constant for converting degree to radian
#define P M_PI / 180.0

struct Cell {
  int x, y;
  int index;
  float cost;
  Cell() : x(0), y(0), index(0), cost(-1) {}
  Cell(int x, int y, int index, float cost)
    : x(x), y(y), index(index), cost(cost) {}
  ~Cell() {}
};



using Heap = priority_queue<Cell>;


inline bool operator<(const Cell& lhs, const Cell& rhs)
{
  return lhs.cost > rhs.cost;
}

/**
 * Calculating the great circle distance using the Vincenty algorithm
 **/
float vincenty_distance(float lon1, float lat1, float lon2, float lat2)
{    // tan U1
  lat1 = lat1 * P;
  lon1 = lon1 * P;
  lat2 = lat2 * P;
  lon2 = lon2 * P;

  const float tan_U1 = (1 - f) * std::tan(lat1);
  const float tan_U2 = (1 - f) * std::tan(lat2);

  // Longitudinal Distance
  const float cos_U1 = 1 / std::sqrt(1 + tan_U1 * tan_U1);
  const float cos_U2 = 1 / std::sqrt(1 + tan_U2 * tan_U2);
  const float sin_U1 = tan_U1 * cos_U1;
  const float sin_U2 = tan_U2 * cos_U2;

  // Iterate until complete
  const float L = lon2 - lon1;
  float lambda = L;
  float diff, sigma;
  float cos_alpha_sq, cos_2sigma_m;
  float cos_sigma, sin_sigma;

  float f16 = f / 16.0;
  while (true) {
    float sin_lambda = sin(lambda);
    float cos_lambda = cos(lambda);

    float c1 = (cos_U2 * sin_lambda) * (cos_U2 * sin_lambda);
    float c2 = (cos_U1 * sin_U2);
    float c3 = (sin_U1 * cos_U2 * cos_lambda);


    sin_sigma = sqrt(c1 + (c2 - c3) * (c2 - c3));
    cos_sigma = sin_U1 * sin_U2 + cos_U1 * cos_U2 * cos_lambda;
    sigma = atan2(sin_sigma, cos_sigma);

    float sin_alpha = (cos_U1 * cos_U2 * sin_lambda) / (sin_sigma);
    cos_alpha_sq = 1 - (sin_alpha * sin_alpha);

    cos_2sigma_m = 0;
    if (cos_alpha_sq != 0) {
      cos_2sigma_m = cos_sigma - (2 * sin_U1 * sin_U2) / (cos_alpha_sq);
    }

    float C = f16 * cos_alpha_sq * (4 + f * (4 - 3 * cos_alpha_sq));

    diff = lambda;
    lambda = L + (1 - C) * f * sin_alpha * (sigma + C * sin_sigma * (cos_2sigma_m + C * cos_sigma * (-1 + 2 * cos_2sigma_m * cos_2sigma_m)));
    diff = lambda - diff;
    if (std::fabs(diff) < 0.00001) { break; }
  }

  // U2
  float semi_minor_squared = pow(semi_minor, 2);
  float u_sq = cos_alpha_sq * (pow(semi_major, 2) - semi_minor_squared) / semi_minor_squared;

  // Compute A, B
  float a = 1 + (u_sq / 16384) * (4096 + u_sq * (-768 + u_sq * (320 - 175 * u_sq)));
  float b = u_sq / 1024 * (256 + u_sq * (-128 + u_sq * (74 - 47 * u_sq)));
  float cos_2sigma_m_squared = cos_2sigma_m * cos_2sigma_m;
  float delta_sigma = b * sin_sigma * (cos_2sigma_m + b / 4 * (cos_sigma * (-1 + 2 * cos_2sigma_m_squared) - b / 6 * cos_2sigma_m * (-3 + 4 * sin_sigma * sin_sigma) * (-3 + 4 * cos_2sigma_m_squared)));
  float s = semi_minor * a * (sigma-delta_sigma);
  return s;
}

void calcCost(int xoff, int yoff, int width, int height, std::vector<float>& data, States& states, Heap& heap, Options& opts)
{
  int xm = xoff + width; //xm
  int ym = yoff + height; // ym

  while (!heap.empty()) {
    Cell cell = heap.top();
    heap.pop();
    if (states.visited[cell.index]) continue;
    states.visited[cell.index] = true;

    float val = data[cell.index];
    int source = states.sources[cell.index];

    for (int i = 0; i < opts.directions; i++) {
      Move& m = states.moves[i];
      int x = cell.x + m.x, y = cell.y + m.y;

      if (y < 0 && opts.rollY) {
        y = -y - 1;
        x = (x + opts.ncols / 2) % opts.ncols;
      }
      if (y >= ym && opts.rollY) {
        y = opts.nrows + (opts.nrows - y - 1);
        x = (x + opts.ncols / 2) % opts.ncols;
      }
      if ((x < 0 || x >= xm) && opts.rollX) {
        x = (x + opts.ncols) % opts.ncols;
      }

      if (x < xoff || x >= xm || y < yoff || y >= ym) {
        continue;
      }
      int index = y * opts.ncols + x;

      float neighborcost = states.costs[index];

      if (neighborcost == 0 || neighborcost == -1) {
        continue;
      }

      if (states.visited[index]) continue;

      float sum = (data[index] + val) * states.dist[y][i] * 0.5 + cell.cost;

      if (neighborcost < -1 || sum < neighborcost) {
        states.costs[index] = sum;
        states.sources[index] = source;
        heap.emplace(Cell{ x, y, index, sum });
      }
    }
  }
}

States accost(std::vector<float>& data, vector<Point>& points, Options& opts) {
  // Exit if invalid block size
  if (opts.ncols % opts.xblocksize) {
    fprintf(stderr, "Invalid number of x blocksize %d", opts.xblocksize);
    exit(EXIT_FAILURE);
  }

  if (opts.nrows % opts.yblocksize) {
    fprintf(stderr, "Invalid number of y blocksize %d", opts.yblocksize);
    exit(EXIT_FAILURE);
  }
  int size = opts.nrows * opts.ncols;

  States states;
  states.costs.resize(size);
  states.sources.resize(size);
  states.visited.resize(size, false);

  // Calculate block sizes
  int row_size = opts.nrows / opts.yblocksize;
  int col_size = opts.ncols / opts.xblocksize;
  int nblocks = opts.xblocksize * opts.yblocksize;

  for (int i = 0; i < size; i++) {
    if (data[i] == opts.nodataval) {
      states.visited[i] = true;
      states.costs[i] = -1;
    }
    else {
      states.costs[i] = -2;
    }
  }
  // Create heaps
  std::vector<Heap> heaps(nblocks);

  for (size_t i = 0; i < points.size(); i++) {
    int row = points[i].y, col = points[i].x;
    int index = row * opts.ncols + col;
    states.costs[index] = 0;
    states.sources[index] = points[i].id;
    states.visited[index] = false;
    if (nblocks == 1) {
      heaps[0].emplace(Cell{ points[i].x, points[i].y, index, 0 });
    }
    else {
      int h = points[i].y / row_size * opts.xblocksize + points[i].x / col_size;
      heaps[h].emplace(Cell{ points[i].x, points[i].y, index, 0 });
    }
  }

  states.moves.resize(opts.directions);
  switch (opts.directions) {
  case 4:
    states.moves = { {0, -1}, {-1, 0}, {1, 0}, {0, 1} };
    break;
  case 8:
    states.moves = { {-1, -1}, {0, -1}, {1, -1}, {-1, 0}, {1, 0}, {-1, 1}, {0, 1}, {1, 1} };
    break;
  case 16:
    states.moves = { {-1, -1}, {0, -1}, {1, -1}, {-1, 0}, {1, 0}, {-1, 1}, {0, 1}, {1, 1},
                     {-1, -2}, {-2, -1}, {-2, 1}, {-1, 2}, {1, 2}, {2, 1}, {2, -1}, {1, -2} };
    break;
  case 20:
    states.moves = { {-1, -1}, {0, -1}, {1, -1}, {-1, 0}, {1, 0}, {-1, 1}, {0, 1}, {1, 1},
                     {-1, -2}, {-2, -1}, {-2, 1}, {-1, 2}, {1, 2}, {2, 1}, {2, -1}, {1, -2},
                     {0, -2}, {-2, 0}, {2, 0}, {0, 2} };
    break;
  case 24:
    states.moves = { {-1, -1}, {0, -1}, {1, -1}, {-1, 0}, {1, 0}, {-1, 1}, {0, 1}, {1, 1},
                     {-1, -2}, {-2, -1}, {-2, 1}, {-1, 2}, {1, 2}, {2, 1}, {2, -1}, {1, -2},
                     {0, -2}, {-2, 0}, {2, 0}, {0, 2}, {-2, -2}, {-2, 2}, {2, 2}, {2, -2} };
    break;
  case 32:
    states.moves = { {-1, -1}, {0, -1}, {1, -1}, {-1, 0}, {1, 0}, {-1, 1}, {0, 1}, {1, 1},
                     {-1, -2}, {-2, -1}, {-2, 1}, {-1, 2}, {1, 2}, {2, 1}, {2, -1}, {1, -2},
                     {-3, -2}, {-3, -1}, {-3, 1}, {-3, 2}, {-2, 3}, {-1, 3}, {1, 3}, {2, 3},
                     {3, 2}, {3, 1}, {3, -1}, {3, -2}, {2, -3}, {1, -3}, {-1, -3}, {-2, -3}};
    break;
  default:
    fprintf(stderr, "Invalid number of directions %d.", opts.directions);
  exit(EXIT_FAILURE);
  }

  states.dist.resize(opts.nrows, std::vector<float>(opts.directions));

  if (opts.isLatLon) {
    // double rdx = opts.xres * M_PI / 360;
    // double rdy = opts.yres * M_PI / 360;
    float y = opts.ymax + opts.yres / 2;
    float lon1 = 0.5 * opts.xres + opts.xmin;
    for (int i = 0; i < opts.nrows; i++) {
      for (int j = 0; j < opts.directions; j++) {
        Move& m = states.moves[j];
        float drx = m.x * opts.xres;
        // float dry = m.y * opts.yres
        float lon2 = lon1 + drx;
        states.dist[i][j] = vincenty_distance(lon1, y, lon2, y + double(m.y) * opts.yres);
      }
      y += opts.yres;
    }
  }
  else {
    for (int i = 0; i < opts.nrows; i++) {
      for (int j = 0; j < opts.directions; j++) {
        Move& m = states.moves[j];
        states.dist[i][j] = (sqrt(pow((m.x) * opts.xres, 2) + pow((m.y) * opts.yres, 2)));
      }
    }
  }

  std::vector<thread> threads(nblocks);

  int t = 0;
  for (int i = 0; i < opts.xblocksize; i++) {
    int row = i * row_size;
    for (int j = 0; j < opts.yblocksize; j++) {
      threads[t] = thread(calcCost, j * col_size, row, col_size, row_size, ref(data), ref(states), ref(heaps[i * opts.xblocksize + j]), ref(opts));
      t++;
    }
  }
  for_each(threads.begin(), threads.end(), [](thread& x) {x.join(); });

  if (nblocks > 1) {
    Heap heap;
    for (int row = row_size - 1; row < opts.nrows - 1; row += row_size) {
      int row_index = row * opts.ncols;
      for (int col = 0; col < opts.ncols; col++) {
        int index = row_index + col;
        if (states.sources[index] > 0) heap.emplace(Cell{ col, row, index, states.costs[index] });
        index += opts.ncols;
        if (states.sources[index] > 0) heap.emplace(Cell{ col, row + 1, index, states.costs[index] });
      }
    }

    for (int row = 0; row < opts.nrows; row++) {
      int row_index = row * opts.ncols;
      for (int col = col_size - 1; col < opts.ncols - 1; col += col_size) {
        int index = row_index + col;
        if (states.sources[index] > 0) heap.emplace(Cell{ col, row, index, states.costs[index] });
        index++;
        if (states.sources[index] > 0) heap.emplace(Cell{ col + 1, row, index, states.costs[index] });
      }
    }

    if (opts.rollX) {
      for (int col = 0; col < opts.ncols; col += opts.ncols - 1) {
        for (int row = 0; row < opts.nrows; row++) {
          int index = row * opts.ncols + col;
          if (states.sources[index] > 0) heap.emplace(Cell{ col, row, index, states.costs[index] });
        }
      }
    }

    if (opts.rollY) {
      for (int col = 0; col < opts.ncols; col++) {
        for (int row = 0; row < opts.nrows; row += opts.nrows - 1) {
          int index = row * opts.ncols + col;
          if (states.sources[index] > 0) heap.emplace(Cell{ col, row, index, states.costs[index] });
        }
      }
    }
    states.visited.clear();
    states.visited.resize(size, false);
    calcCost(0, 0, opts.ncols, opts.nrows, ref(data), ref(states), heap, opts);
  }
  //states.costs.clear();
  //states.sources.clear();
  states.visited.clear();
  states.dist.clear();
  states.moves.clear();
  return states;
}

vector<string> split(string s, string delimiter) {
  size_t pos_start = 0, pos_end, delim_len = delimiter.length();
  string token;
  vector<string> res;

  while ((pos_end = s.find(delimiter, pos_start)) != string::npos) {
    token = s.substr(pos_start, pos_end - pos_start);
    pos_start = pos_end + delim_len;
    res.push_back(token);
  }

  res.push_back(s.substr(pos_start));
  return res;
}

void writeRaster(GDALDataset* poDataset, GDALDataset* srcDataset, options opts)
{
  const int ncols = poDataset->GetRasterXSize();
  const int nrows = poDataset->GetRasterYSize();
  // const int nbands = poDataset->GetRasterCount();

  OGRSpatialReference osr(poDataset->GetProjectionRef());
  bool isLatLon = osr.IsGeographic();

  float xres = 1, yres = 1, xmin = 0, ymax = 0, nodataval = -9999.0;

  double adfGeoTransform[6];
  if (poDataset->GetGeoTransform(adfGeoTransform) == CE_None)
  {
    xmin = adfGeoTransform[0];
    ymax = adfGeoTransform[3];
    xres = adfGeoTransform[1];
    yres = adfGeoTransform[5];
  }

  GDALRasterBand* poBand;
  poBand = poDataset->GetRasterBand(1);
  nodataval = poBand->GetNoDataValue();

  vector<float> indata(nrows * ncols);

  float* pafScanline = (float*)CPLMalloc(sizeof(float) * ncols);

  for (int i = 0; i < nrows; i++) {
    poBand->RasterIO(GF_Read, 0, i, ncols, 1, pafScanline, ncols, 1, GDT_Float32, 0, 0);
    for (int j = 0; j < ncols; j++) {
      if (pafScanline[j] == nodataval) {
        indata[i * ncols + j] = -9999.0;
      }
      else {
        indata[i * ncols + j] = pafScanline[j];
      }

    }
  }
  CPLFree(pafScanline);

  GDALRasterBand* srcBand;
  srcBand = srcDataset->GetRasterBand(1);
  nodataval = srcBand->GetNoDataValue();

  vector<Point> points;
  float* pntsScanline = (float*)CPLMalloc(sizeof(float) * ncols );

  int count = 1;
  for (int i = 0; i < nrows; i++) {
    srcBand->RasterIO(GF_Read, 0, i, ncols, 1, pntsScanline, ncols, 1, GDT_Float32, 0, 0);
    for (int j = 0; j < ncols; j++) {
      if (pntsScanline[j] != nodataval) {
        points.push_back(Point(int(pntsScanline[j]), j, i));
        points.resize(count);
        count++;
      }
    }
  }
  CPLFree(pntsScanline);

  Options options(nrows, ncols, opts.xblocksize, opts.yblocksize, opts.directions, xres, yres, xmin, ymax, nodataval, isLatLon, opts.rollX, opts.rollY);

  const char* pszFormat = poDataset->GetDriver()->GetDescription();

  GDALDriver* poDriver;


  GDALDataset* dstDstDS1;
  char** papszOptions = NULL;

  poDriver = GetGDALDriverManager()->GetDriverByName(pszFormat);

  if (opts.format.c_str() != NULL){
    poDriver = GetGDALDriverManager()->GetDriverByName(opts.format.c_str());
    if (poDriver == NULL){
      fprintf(stderr, "Wrong output format! %s", opts.format.c_str());
      exit(EXIT_FAILURE);
    }
  }

  string str(poDriver->GetMetadataItem(GDAL_DMD_EXTENSIONS));
  vector<string> exts = split(str, " ");

  string outFilename1 = "/access_minimum." + exts[0];
  string outFilename2 = "/access_zones." + exts[0];

  if(opts.filename1.c_str() != NULL){
    outFilename1 = opts.filename1;
  }

  if(opts.filename2.c_str() != NULL){
    outFilename2 = opts.filename2;
  }

  dstDstDS1 = poDriver->Create(outFilename1.c_str(), ncols, nrows, 1, GDT_Float32, papszOptions);
  dstDstDS1->SetGeoTransform(adfGeoTransform);
  dstDstDS1->SetProjection(poDataset->GetProjectionRef());
  GDALRasterBand* dstBand1;
  dstBand1 = dstDstDS1->GetRasterBand(1);
  dstBand1->SetNoDataValue(-9999.0);

  GDALDataset* dstDstDS2;
  dstDstDS2 = poDriver->Create(outFilename2.c_str(), ncols, nrows, 1, GDT_Int32, papszOptions);
  dstDstDS2->SetGeoTransform(adfGeoTransform);
  dstDstDS2->SetProjection(poDataset->GetProjectionRef());
  GDALRasterBand* dstBand2;
  dstBand2 = dstDstDS2->GetRasterBand(1);
  dstBand2->SetNoDataValue(-9999);

  States states = accost(ref(indata), ref(points), ref(options));
  float* rowBuff1 = (float*)CPLMalloc(sizeof(float) * ncols);
  int* rowBuff2 = (int*)CPLMalloc(sizeof(int) * ncols);

  for (int i = 0; i < nrows; i++) {
    for (int j = 0; j < ncols; j++) {
      int index = i * ncols + j;
      rowBuff1[j] = states.costs[index] == -1 ? -9999.0 : states.costs[index];
      rowBuff2[j] = states.costs[index] == -1 ? -9999 : states.sources[index];
    }
    dstBand1->RasterIO(GF_Write, 0, i, ncols, 1, rowBuff1, ncols, 1, GDT_Float32, 0, 0);
    dstBand2->RasterIO(GF_Write, 0, i, ncols, 1, rowBuff2, ncols, 1, GDT_Int32, 0, 0);
  }
  CPLFree(rowBuff1);
  CPLFree(rowBuff2);
  CPLFree(papszOptions);
  if (dstDstDS1 != NULL)
    GDALClose((GDALDatasetH)dstDstDS1);
  if (dstDstDS2 != NULL)
    GDALClose((GDALDatasetH)dstDstDS2);
}

