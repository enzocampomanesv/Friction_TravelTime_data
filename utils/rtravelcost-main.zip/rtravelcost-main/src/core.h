#pragma once
#define _USE_MATH_DEFINES
#define _CRT_SECURE_NO_WARNINGS
#include <cmath>
#include<iostream>
#include<vector>
#include <Rcpp.h>
#include "objects.h"

#include <gdal_priv.h>
#include<cpl_conv.h>
#include "limits.h"
#include<gdal_alg.h>

using namespace std;
using namespace Rcpp;

States accost(std::vector<float>& data, std::vector<Point>& points, Options& opts);

void writeRaster(GDALDataset* poDataset, GDALDataset* srcDataset, options opts);
