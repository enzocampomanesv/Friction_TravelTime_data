# TravelCost Package

## Introduction

## Description

### Requirements

- Raster package
- Friction raster file, any format supported by GDAL
- Target layer in raster/vector format supported by GDAL


### Usage

```
# Option A
library(raster)
library(rtravelcost)

#Robert - I think we can remove the following two lines
memory.limit(999999999999)
memory.size(999999999999)


startTime = Sys.time()
result <- accumcosts(x="/inputs/frictiongrid.tif", y="/inputs/targetcities.shp",
           directions=8, outputpath1="/outputs/result1.tif",
           outputpath2="/outputs/result2.tif", nblocks=5, format="GTiff", field="fid", rollX=FALSE, rollY=FALSE)

print(Sys.time() - startTime)

#Option B

library(raster)
library(rtravelcost)

x <- raster(nrows=6, ncols=7, xmn=0, xmx=7, ymn=0, ymx=6, crs="+proj=utm +units=m")
x[] <- c(2, 2, 1, 1, 5, 5, 5,
         2, 2, 8, 8, 5, 2, 1,
         7, 1, 1, 8, 2, 2, 2,
         8, 7, 8, 8, 8, 8, 5,
         8, 8, 1, 1, 5, 3, 9,
         8, 1, 1, 2, 5, 3, 9)


y <- raster(nrows=6, ncols=7, xmn=0, xmx=7, ymn=0, ymx=6, crs="+proj=utm +units=m")
y[] <- c(NA, NA, NA, NA, NA, NA, NA,
         NA, NA, NA, NA, NA, NA, NA,
         NA, NA, NA, NA, NA, NA, NA,
         NA, NA, NA, NA, NA, NA, NA,
         NA, NA, NA, NA, NA, 10, NA,
         NA, NA, NA, NA, NA, NA, NA)


result = accosts(x, y, 4, 1, FALSE, FALSE)

plot(result$layer.1)
text(result$layer.1)

```

#### Usage - Explanation
## Arguments
`x` : character. The path to the friction raster

`y` : character. The path to the targets raster/vector data. Accepts points, linestring, polygons in vector or raster format. Must be in the same reference and resolution as the friction raster

`directions` : numeric. Specifies the number of neighbors for each cell. Cells can have 4, 8, 16, 20, 24, 32 neighbors. The default option is 8.

## Additional arguments:

`nblocks` : numeric. Set this option to enable parallel computation. Blocksize is the number of partitions of the raster in the x and y direction.

`rollX` : Logical. Set this option to TRUE to wrap the grid in the E-W direction if your friction raster is using a spherical reference system.

`rollY` : Logical. Set this option to TRUE to wrap the grid in the N-E direction if your friction raster is using a spherical reference system.

`outputpath1` : character. Points to the path of the output accumulative costs raster. If this output path is not specified, the output raster will be written to the disk with a default name of codeaccess_min.tf

`outputpath2` : character. Points to the path of the output catchments raster.  If this output path is not specified, the output raster will be written to the disk with a default name of access_zones.tf

`field` : character. If y is a vector, specify the attribute with unique identifier for the targets.

`format` character. Choose this to indicate the format for the output rasters. Default is GTiff.


#### Output
The output is a RasterStack and two raster files. One file is the output for the minimum travel cost and the other is the catchment raster for every source. The value of the catchment corresponds to the identifier of the source.

### Research

## Support Development

1. On Windows, you need to first install recent version of [Rtools](https://cran.r-project.org/bin/windows/Rtools/) to get a C++ compiler that R can use.
1. Clone the project repository using ` git clone git@github.com:GIP-ITC-UniversityTwente/rtravelcost.git ` 
1. Start your RStudio software.
1. To build a new package, go to the top menu and select `Build -> Build Binary Package`

