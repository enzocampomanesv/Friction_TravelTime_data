#!/bin/bash

g++ -o terra -std=c++11  -I../src/  ../src/core.cpp  ../src/r_core.cpp  \
	-lgeos_c -lgdal -lproj `gdal-config --cflags` `gdal-config --libs` `gdal-config --dep-libs` -Dstandalone
